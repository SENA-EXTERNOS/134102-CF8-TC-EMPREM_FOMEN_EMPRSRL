function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5ve8IQC4aEj":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

